import express from "express";
import fetch from "node-fetch";
import bodyParser from "body-parser";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(bodyParser.json());

// 🗣️ Чат (OpenAI API)
app.post("/chat", async (req, res) => {
  const { message } = req.body;
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "Ти си AI момиче." },
          { role: "user", content: message }
        ]
      })
    });

    const data = await response.json();
    res.json({ reply: data.choices[0].message.content });
  } catch (e) {
    res.status(500).json({ error: "Chat API error" });
  }
});

// 🎨 Аватар (Stable Diffusion API)
app.post("/avatar", async (req, res) => {
  const { prompt } = req.body;
  try {
    const response = await fetch("https://api.stability.ai/v2beta/stable-image/generate/core", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.STABLE_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ prompt, output_format: "png" })
    });

    const buffer = await response.arrayBuffer();
    res.set("Content-Type", "image/png");
    res.send(Buffer.from(buffer));
  } catch (e) {
    res.status(500).json({ error: "Avatar API error" });
  }
});

// 🔊 Глас (ElevenLabs)
app.post("/voice", async (req, res) => {
  const { text } = req.body;
  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/EXAVITQu4vr4xnSDxMaL`, {
      method: "POST",
      headers: {
        "xi-api-key": process.env.ELEVEN_API_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ text })
    });

    const audio = await response.arrayBuffer();
    res.set("Content-Type", "audio/mpeg");
    res.send(Buffer.from(audio));
  } catch (e) {
    res.status(500).json({ error: "Voice API error" });
  }
});

app.listen(5000, () => console.log("🚀 Backend running on http://localhost:5000"));
