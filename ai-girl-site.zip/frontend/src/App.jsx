import { useState } from "react";

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [avatar, setAvatar] = useState(null);
  const [voice, setVoice] = useState(null);

  const sendMessage = async () => {
    const res = await fetch("http://localhost:5000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setMessages([...messages, { role: "user", text: input }, { role: "ai", text: data.reply }]);
    setInput("");
  };

  const generateAvatar = async () => {
    const res = await fetch("http://localhost:5000/avatar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: "anime girl portrait" })
    });
    const blob = await res.blob();
    setAvatar(URL.createObjectURL(blob));
  };

  const speak = async (text) => {
    const res = await fetch("http://localhost:5000/voice", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
    const blob = await res.blob();
    setVoice(URL.createObjectURL(blob));
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">AI Girl Chat</h1>

      {avatar && <img src={avatar} alt="AI Girl" className="rounded-2xl shadow-lg mb-4" />}

      <div className="space-y-2 mb-4">
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "text-right" : "text-left"}>
            <p className={`p-2 rounded-xl ${m.role === "user" ? "bg-blue-200" : "bg-pink-200"}`}>
              {m.text}
            </p>
            {m.role === "ai" && (
              <button onClick={() => speak(m.text)} className="text-sm underline mt-1">🔊 Чуй</button>
            )}
          </div>
        ))}
      </div>

      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className="border rounded-xl p-2 w-full mb-2"
        placeholder="Напиши съобщение..."
      />
      <button onClick={sendMessage} className="bg-blue-500 text-white px-4 py-2 rounded-xl">Изпрати</button>
      <button onClick={generateAvatar} className="ml-2 bg-pink-500 text-white px-4 py-2 rounded-xl">Създай аватар</button>

      {voice && <audio controls src={voice} autoPlay />}
    </div>
  );
}
